#include "arbol.h"
Arbol genArbol(char *exPostfija);
int esOperador(char simbolo);

